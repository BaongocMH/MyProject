<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý sản phẩm</title>
    
    <!-- Bootstrap & FontAwesome -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

    <style>
        /* Header sang trọng */
        .navbar-custom {
            background-color: #212529; /* Màu tối */
            padding: 12px 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .navbar-custom .navbar-brand {
            font-weight: bold;
            font-size: 22px;
            color: #ffffff;
        }
        .navbar-custom .nav-link {
            color: #ffffff;
            font-size: 16px;
            transition: color 0.3s ease-in-out;
        }
        .navbar-custom .nav-link:hover {
            color: #f8d210; /* Màu vàng ánh kim */
        }

        /* Nút tìm kiếm */
        .search-box {
            background: #343a40; /* Màu tối */
            border: none;
            color: #ffffff;
            border-radius: 20px;
            padding: 8px 15px;
        }
        .search-box::placeholder {
            color: #cccccc;
        }
        .btn-search {
            background: #f8d210; /* Màu vàng ánh kim */
            color: #212529;
            border-radius: 50%;
            padding: 8px 10px;
            border: none;
            transition: background 0.3s ease-in-out;
        }
        .btn-search:hover {
            background: #ffc107; /* Vàng sáng hơn */
        }

        /* Dropdown User */
        .dropdown-menu {
            background: #343a40; /* Màu tối */
        }
        .dropdown-menu a {
            color: #ffffff;
        }
        .dropdown-menu a:hover {
            background: #495057;
        }
        .login-form {
            margin-bottom: 50px; /* Điều chỉnh khoảng cách phù hợp */
        }
        .content {
            min-height: calc(100vh - 150px); /* Điều chỉnh giá trị cho phù hợp */
        }
    </style>
</head>
<body>

    <!-- HEADER -->
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom">
        <a class="navbar-brand" href="#"><i class="fas fa-box-open"></i> Quản lý sản phẩm</a>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="/product"><i class="fas fa-list"></i> Danh sách sản phẩm</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/product/add"><i class="fas fa-plus-circle"></i> Thêm sản phẩm</a>
                </li>

                <!-- Form tìm kiếm -->
                <li class="nav-item">
                    <form class="form-inline" action="/Product/search" method="get">
                        <input class="form-control search-box mr-sm-2" type="search" placeholder="Tìm sản phẩm..." aria-label="Search" name="search">
                        <button class="btn btn-search my-2 my-sm-0" type="submit"><i class="fas fa-search"></i></button>
                    </form>
                </li>

                <!-- Dropdown User -->
                <li class="nav-item dropdown">
                    <?php if (SessionHelper::isLoggedIn()): ?>
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-user"></i> <?php echo $_SESSION['username']; ?>
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="/account/logout">Đăng xuất</a>
                        </div>
                    <?php else: ?>
                        <a class="nav-link" href="/account/login"><i class="fas fa-sign-in-alt"></i> Đăng nhập</a>
                    <?php endif; ?>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container mt-4">
        <!-- Nội dung quản lý sản phẩm -->
    </div>

    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
