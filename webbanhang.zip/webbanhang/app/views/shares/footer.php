<!-- Phần đăng nhập -->
<div class="login-container">
    <!-- Form đăng nhập ở đây -->
</div>

<!-- Phân cách giữa đăng nhập và footer -->
<div class="space-between"></div>

<!-- Footer -->
<footer class="footer bg-dark text-light pt-4">
    <div class="container">
        <div class="row">
            <!-- Cột thông tin liên hệ -->
            <div class="col-lg-6 col-md-12 mb-4">
                <h5 class="text-uppercase font-weight-bold">Quản lý sản phẩm</h5>
                <p>Hệ thống quản lý sản phẩm giúp bạn theo dõi và cập nhật thông tin sản phẩm dễ dàng.</p>
            </div>
            <!-- Cột liên kết nhanh -->
            <div class="col-lg-3 col-md-6 mb-4">
                <h5 class="text-uppercase font-weight-bold">Liên kết nhanh</h5>
                <ul class="list-unstyled">
                    <li><a href="/Product/" class="footer-link">Danh sách sản phẩm</a></li>
                    <li><a href="/Product/add" class="footer-link">Thêm sản phẩm</a></li>
                </ul>
            </div>
            <!-- Cột mạng xã hội -->
            <div class="col-lg-3 col-md-6 mb-4">
                <h5 class="text-uppercase font-weight-bold">Kết nối với chúng tôi</h5>
                <div class="social-icons">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                </div>
            </div>
        </div>
    </div>
    <!-- Dòng bản quyền -->
    <div class="text-center py-3 bg-secondary text-white">
        © 2025 Quản lý sản phẩm. All rights reserved.
    </div>
</footer>

<!-- Font Awesome Icons -->
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>

<style>
    /* Thêm khoảng cách dưới phần đăng nhập */
    .login-container {
        margin-bottom: 50px; /* Tạo khoảng cách dưới form */
        padding: 20px; /* Có thể thêm padding để tạo khoảng trắng xung quanh */
        background-color: #f8f9fa; /* Màu nền cho phần đăng nhập */
        border-radius: 8px; /* Bo tròn các góc */
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Thêm bóng đổ nhẹ cho phần đăng nhập */
    }

    /* Phân cách giữa đăng nhập và footer */
    .space-between {
        height: 30px; /* Độ cao phân cách */
        background-color: #f8f9fa; /* Màu nền giống với màu nền của trang */
    }

    footer {
        padding-top: 30px; /* Thêm khoảng cách phía trên footer */
        background-color: #343a40; /* Màu nền footer */
        margin-top: 20px; /* Thêm khoảng cách trên footer nếu cần */
    }
</style>
