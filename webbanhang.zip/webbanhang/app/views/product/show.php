<!DOCTYPE html>
<html>
<head>
    <title>Chi tiết sản phẩm</title>
    <link rel="stylesheet" type="text/css" href="/public/css/style.css">
    <style>
        .product-image {
            width: 100%;
            max-width: 500px;
            height: auto;
            margin: 0 auto;
            display: block;
        }
        .card-body {
            padding: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Chi tiết sản phẩm</h1>

        <?php if ($product): ?>
            <div class="card">
                <div class="card-body">
                    <img src="<?= htmlspecialchars($product->image_url, ENT_QUOTES, 'UTF-8'); ?>" 
                         alt="<?= htmlspecialchars($product->name, ENT_QUOTES, 'UTF-8'); ?>" 
                         class="product-image">
                    
                    <h5 class="card-title"><?= htmlspecialchars($product->name, ENT_QUOTES, 'UTF-8'); ?></h5>
                    <p class="card-text"><?= htmlspecialchars($product->description, ENT_QUOTES, 'UTF-8'); ?></p>
                    <p class="card-text">Giá: <?= number_format($product->price, 0, ',', '.'); ?> VND</p>

                    <!-- Các nút Sửa và Xóa chỉ hiện với admin -->
                    <?php if (isset($_SESSION['user']) && $_SESSION['user']['role'] === 'admin'): ?>
                        <a href="/Product/edit/<?= $product->id; ?>" class="btn btn-warning">Sửa</a>
                        <a href="/Product/delete/<?= $product->id; ?>" class="btn btn-danger" onclick="return confirm('Bạn có chắc chắn muốn xóa sản phẩm này?');">Xóa</a>
                    <?php endif; ?>
                </div>
            </div>
        <?php else: ?>
            <p>Không tìm thấy sản phẩm.</p>
        <?php endif; ?>

        <a href="/Product" class="btn btn-primary">Quay lại danh sách</a>
    </div>

    <?php include 'app/views/shares/footer.php'; ?>
</body>
</html>
