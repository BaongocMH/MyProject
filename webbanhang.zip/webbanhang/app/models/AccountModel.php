<?php
class AccountModel
{
private $conn;
private $table_name = "account";
public function __construct($db)
{
$this->conn = $db;
}
public function getAccountByUsername($username)
{
$query = "SELECT * FROM account WHERE username = :username";
$stmt = $this->conn->prepare($query);
$stmt->bindParam(':username', $username, PDO::PARAM_STR);
$stmt->execute();
$result = $stmt->fetch(PDO::FETCH_OBJ);
return $result;
}
public function save($username, $fullname, $password, $role = 'user') {
    $query = "INSERT INTO account (username, fullname, password, role) VALUES (:username, :fullname, :password, :role)";
    $stmt = $this->conn->prepare($query);

    // Bind parameters
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':fullname', $fullname);
    $stmt->bindParam(':password', $password);
    $stmt->bindParam(':role', $role);

    if ($stmt->execute()) {
        return true;
    }
    return false;
}


}