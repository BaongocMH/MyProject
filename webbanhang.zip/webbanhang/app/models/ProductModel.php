<?php
class ProductModel
{
private $conn;
private $table_name = "product";
public function __construct($db)
{
$this->conn = $db;
}
public function getProducts()
{
    $query = "SELECT p.id, p.name, p.description, p.price, p.image as image_url, c.name as category_name
              FROM " . $this->table_name . " p
              LEFT JOIN category c ON p.category_id = c.id";

    $stmt = $this->conn->prepare($query);
    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_OBJ);
    return $result;
}
public function getProductById($id)
{
$query = "SELECT * FROM " . $this->table_name . " WHERE id = :id";
$stmt = $this->conn->prepare($query);
$stmt->bindParam(':id', $id);
$stmt->execute();
$result = $stmt->fetch(PDO::FETCH_OBJ);
return $result;
}
public function addProduct($name, $description, $price, $category_id, $image)
{
$errors = [];
if (empty($name)) {
$errors['name'] = 'Tên sản phẩm không được để trống';
}
if (empty($description)) {
$errors['description'] = 'Mô tả không được để trống';
}
if (!is_numeric($price) || $price < 0) {
$errors['price'] = 'Giá sản phẩm không hợp lệ';
}
if (count($errors) > 0) {
return $errors;
}
$query = "INSERT INTO " . $this->table_name . " (name, description, price,
category_id, image) VALUES (:name, :description, :price, :category_id, :image)";
$stmt = $this->conn->prepare($query);
$name = htmlspecialchars(strip_tags($name));
$description = htmlspecialchars(strip_tags($description));
$price = htmlspecialchars(strip_tags($price));
$category_id = htmlspecialchars(strip_tags($category_id));
$image = ($image);
$query = "INSERT INTO " . $this->table_name . " (name, description, price, category_id, image) VALUES (:name, :description, :price, :category_id, :image)";
$stmt->bindParam(':name', $name);
$stmt->bindParam(':description', $description);
$stmt->bindParam(':price', $price);
$stmt->bindParam(':category_id', $category_id);
$stmt->bindParam(':image', $image);
if ($stmt->execute()) {
return true;
}
return false;
}
public function updateProduct($id, $name, $description, $price, $category_id,
$image)
{
$query = "UPDATE " . $this->table_name . " SET name=:name,
description=:description, price=:price, category_id=:category_id, image=:image WHERE
id=:id";
$stmt = $this->conn->prepare($query);
$name = htmlspecialchars(strip_tags($name));
$description = htmlspecialchars(strip_tags($description));
$price = htmlspecialchars(strip_tags($price));
$category_id = htmlspecialchars(strip_tags($category_id));
$image = htmlspecialchars(strip_tags($image));
$query = "UPDATE " . $this->table_name . " SET name=:name, description=:description, price=:price, category_id=:category_id, image=:image WHERE id=:id";
    $stmt = $this->conn->prepare($query);
    $stmt->bindParam(':id', $id);
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':description', $description);
    $stmt->bindParam(':price', $price);
    $stmt->bindParam(':category_id', $category_id);
    $stmt->bindParam(':image', $image);
if ($stmt->execute()) {
return true;
}
return false;
}
public function deleteProduct($id)
{
$query = "DELETE FROM " . $this->table_name . " WHERE id=:id";
$stmt = $this->conn->prepare($query);
$stmt->bindParam(':id', $id);
if ($stmt->execute()) {
return true;
}
return false;
}
public function setSoBan()
{
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $_SESSION['so_ban'] = $_POST['so_ban'];
        header('Location: /Product/cart');  // Chuyển hướng về trang giỏ hàng
    }
}
public function search($searchTerm) {
    // Kiểm tra xem có từ khóa tìm kiếm không
    if (!empty($searchTerm)) {
        // Gọi phương thức tìm kiếm trong model và truyền vào từ khóa tìm kiếm
        $products = $this->searchProducts($searchTerm);

        // Hiển thị kết quả tìm kiếm
        include 'app/views/product/search.php';  // Gọi view để hiển thị kết quả
    } else {
        // Nếu không có từ khóa tìm kiếm, hiển thị tất cả sản phẩm
        $this->getProducts();
    }
}
public function searchProducts($searchTerm) {
    $query = "SELECT p.id, p.name, p.description, p.price, p.image as image_url, c.name as category_name
              FROM " . $this->table_name . " p
              LEFT JOIN category c ON p.category_id = c.id
              WHERE p.name LIKE :searchTerm OR p.description LIKE :searchTerm";

    $stmt = $this->conn->prepare($query);
    $searchTerm = "%" . $searchTerm . "%";  // Thêm dấu % vào trước và sau từ khóa tìm kiếm
    $stmt->bindParam(':searchTerm', $searchTerm);
    $stmt->execute();

    return $stmt->fetchAll(PDO::FETCH_OBJ);  // Trả về danh sách sản phẩm tìm được
}


}
?>